<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cek Identitas</title>
</head>
<body>
<div class="content"> 
    <header>    <!-- Section header  -->
        <h1>PRESENSI ONLINE KARYAWAN</h1>
    </header>
    <hr />
    <menu>      <!-- Section menu  -->
        <button type="button"><a href="presensi.php">Presensi</a></button>
        <button type="button"><a href="cekpresensi.html">Cek Presensi</a></button>
        <button type="button"><a href="cekidentitas.php">Cek Identitas</a></button>
    </menu>
    <main>      <!-- Section main -->
    <?php
    include 'koneksi.php';
    ?>
        <form method="get">
            <label>ID karyawan</label>
            <input placeholder="Masukkan Id karyawan Anda" type="text" name="id_karyawan">
            <input type="Submit" name="tombol" value="Submit">
        </form>
        <p>
            <label for="password" id="password" name="password">Password</label>
        <input placeholder="Masukkan Password Anda" type="password" name="password"> 
        </p>
        <table border="1" width="500" >
        <?php

           if(isset($_GET['id_karyawan'])){
               $idkar = $_GET['id_karyawan'];
               $sql = mysqli_query($koneksi,"select * from presensi where id_karyawan='$idkar'");
           }else{
               $sql = mysqli_query($koneksi,"select * from presensi where id_karyawan");
           }

           while($data = mysqli_fetch_array($sql)){
           ?>
           <tr>
               <td>Nama</td>
               <td><?php echo $data['nama']; ?></td>
           </tr>
           <tr>
               <td>Tempat, Tanggal Lahir</td>
               <td><?php echo $data['tgl']; ?></td>
           </tr>
           <tr>
               <td>Alamat</td>
               <td><?php echo $data['alamat']; ?></td>
           </tr>
           <tr>
               <td>Status</td>
               <td><?php echo $data['status']; ?></td>
           </tr>
            <?php
           }
           ?>
        </table>
    </main>
    <hr />
    <footer>    <!-- Section Footeer  -->
        <p>Create by Team9</p>
    </footer>
</div>
</body>
</html>